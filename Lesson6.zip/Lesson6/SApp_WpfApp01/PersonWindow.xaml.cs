﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SApp_WpfApp01
{
    /// <summary>
    /// Interaction logic for PersonalWindow.xaml
    /// </summary>
    public partial class PersonWindow : Window
    {
        public ObservableCollection<Person> PersonList = new ObservableCollection<Person>();
        static public List<Department> DepartmentList = new List<Department>();
        public ObservableCollection<ChangePerson> ChangePersonList = new ObservableCollection<ChangePerson>();

        public PersonWindow()
        {
            InitializeComponent();
            this.DataContext = this;

            DepartmentList.AddRange(new[] {
                new Department("Первый"),
                new Department("Второй"),
                new Department("Технический")
                });

            using(StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "Persons.txt", Encoding.UTF8))
            {
                while (!sr.EndOfStream)
                {
                    string[] str = sr.ReadLine().Split(';');
                    PersonList.Add(new Person(str[0], Convert.ToDateTime(str[1]), 
                        (Controls.Gender)Convert.ToInt32(str[2]), DepartmentList[Convert.ToInt32(str[3])]));
                }
            }

            personListView.ItemsSource = PersonList;
            changeList.ItemsSource = ChangePersonList;
            ColB.Width = PersonList[0].Birthday.ToString().Length * 10;
            PersonList.CollectionChanged += PersonList_CollectionChanged;
            departmentComboBox.ItemsSource = DepartmentList;
        }

        private void PersonList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    Person newPerson = e.NewItems[0] as Person;
                    ChangePersonList.Add(new ChangePerson( $"Добавление: {newPerson}"));
                    break;
                case NotifyCollectionChangedAction.Remove:
                    Person OldPerson = e.OldItems[0] as Person;
                    ChangePersonList.Add(new ChangePerson( $"Удаление: {OldPerson}"));
                    break;
            }
        }

        private void personListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count != 0)
            {
                nameTextBox.Text = (e.AddedItems[0] as Person).Name;
                birthdayDatePicker.SelectedDate = (e.AddedItems[0] as Person).Birthday;
                genderControl.Gender = (e.AddedItems[0] as Person).Gender;
                departmentComboBox.SelectedItem = (e.AddedItems[0] as Person).Department;
            }
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            if (personListView.SelectedItem != null)
            {
                var person = (Person)personListView.SelectedItem;

                person.Name = nameTextBox.Text;
                person.Birthday = (DateTime)birthdayDatePicker.SelectedDate;
                person.Gender = genderControl.Gender;
                person.Department = (Department)departmentComboBox.SelectedItem;
            }
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddPersonWindow wnd = new AddPersonWindow();
            if(wnd.ShowDialog() == true)
                PersonList.Add(wnd.Person);
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (personListView.SelectedItem != null)
                PersonList.Remove((Person)personListView.SelectedItem);
        }

        private void btnCLearChange_Click(object sender, RoutedEventArgs e)
        {
            ChangePersonList.Clear();
        }
    }
}
