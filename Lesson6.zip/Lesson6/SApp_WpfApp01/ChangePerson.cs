﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SApp_WpfApp01
{
    public class ChangePerson: INotifyPropertyChanged
    {
        private string _change;
        public string Change
        {
            get { return _change; }
            set { _change = value; NotifyPropertyChanged(); }
        }

        public ChangePerson(string change)
        {
            Change = change;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
