﻿using SApp_WpfApp01.Controls;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SApp_WpfApp01
{
    public class Person: INotifyPropertyChanged
    {
        private string _name;
        private DateTime _birthday;
        private Gender _gender;
        private Department _departament;

        public string Name
        {
            get { return _name; }
            set { _name = value; NotifyPropertyChanged(); }
        }
        public DateTime Birthday
        {
            get { return _birthday; }
            set { _birthday = value; NotifyPropertyChanged(); }
        }
        public Gender Gender
        {
            get { return _gender; }
            set { _gender = value; NotifyPropertyChanged(); }
        }
        public Department Department
        {
            get { return _departament; }
            set { _departament = value; NotifyPropertyChanged(); }
        }

        public Person(string name, DateTime birthday, Gender gender, Department department)
        {
            Name = name;
            Birthday = birthday;
            Gender = gender;
            Department = department;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public override string ToString()
        {
            return $"имя: {Name}, др: {Birthday}, пол: {Gender}, департамент: {Department}";
        }
    }
}
